 <tr>
    <td><img src="images/HMS_Banner.jpg" width="100%" height="150" /></td>
  </tr>