<table width="100%" border="0">
      <tr>
        <td>
		<a href="showpatient.php" class="menu"> Show Patient Detail</a></td>
        <td><a href="about.php" class="menu"></a> </td>


       
        <td>
		<?php
		 if(isset($_SESSION["user"]))
		 {
		  echo "Welcome : ".$_SESSION["user"]." <a href='logout.php'>Logout</a>";
		 }
		
		?>
		</td>
      </tr>
    </table>