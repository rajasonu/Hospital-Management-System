<table width="100%" border="0">
      <tr>
        <td>
		<a href="appointmentwithdoc.php" class="menu"> Appointment With Doctor</a></td>
        <td><a href="gettreatment.php" class="menu">Get Your Treatment</a> </td>


       
        <td>
		<?php
		 if(isset($_SESSION["user"]))
		 {
		  echo "Welcome : ".$_SESSION["user"]." <a href='logout.php'>Logout</a>";
		 }
		
		?>
		</td>
      </tr>
    </table>