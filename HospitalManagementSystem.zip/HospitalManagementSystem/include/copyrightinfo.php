<tr>
    <td align="center" class="copyright">www.HospitalManagementSyste.com All Right reserved. 2021 Website Designed and developed by Garima Mamar and Dipti Sharma.</td>
  </tr>