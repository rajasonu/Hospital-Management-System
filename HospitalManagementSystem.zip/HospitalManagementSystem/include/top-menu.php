<table width="100%" border="0">
      <tr>
        <td>
		<a href="index.php" class="menu">Home</a></td>
        <td><a href="about.php" class="menu">About Us</a> </td>


        <td><a href="patientregistration.php" class="menu">Patient Registration</a></td>
        <td><a href="patientlogin.php" class="menu">Patient Login</a> </td>

        <td><a href="doctorlogin.php" class="menu">Doctor Login </a></td>
        <td><a href="affiliatedcollege.php" class="menu"></a> </td>
		<td><a href="placement.php" class="menu"></a> </td>
        <td><a href="contactus.php" class="menu">Contact Us </a></td>
      </tr>
    </table>