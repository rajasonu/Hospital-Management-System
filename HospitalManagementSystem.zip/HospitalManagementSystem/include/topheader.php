<table width="100%" border="0">
      <tr>
      <td width="10%"><img src="images/1_cq2-hwx8Cev0eXpaW6CIHg.jpeg" width="272" height="134" /></td>
        <td width="2%">&nbsp;</td>
        <td width="88%">
         <h1 class="test3"> Hospital Management System</h1></td>
      </tr>
    </table>